import { useMemo } from "react";
import "./backdrop.css";

// Small seeded random so the skyline is identical on every load and on every re-render.
function seededRandom(seed) {
  let state = seed;
  return () => {
    state = (state * 16807) % 2147483647;
    return (state - 1) / 2147483646;
  };
}

function Skyline({ seed, count, minHeight, maxHeight, lit = false, className }) {
  const buildings = useMemo(() => {
    const random = seededRandom(seed);
    const slot = 1600 / count;
    return Array.from({ length: count }, (_, index) => {
      const width = slot * (0.78 + random() * 0.5);
      const height = minHeight + random() * (maxHeight - minHeight);
      const x = index * slot - 10;
      const windows = [];
      if (lit) {
        for (let row = 0; row < Math.floor(height / 26); row += 1) {
          for (let column = 0; column < Math.floor(width / 18); column += 1) {
            if (random() > 0.62) windows.push({ x: x + 8 + column * 18, y: 400 - height + 12 + row * 26 });
          }
        }
      }
      return { x, width, height, windows, antenna: random() > 0.82 };
    });
  }, [seed, count, minHeight, maxHeight, lit]);

  return (
    <svg className={className} viewBox="0 0 1600 400" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
      {buildings.map((building, index) => (
        <g key={index}>
          <rect x={building.x} y={400 - building.height} width={building.width} height={building.height} />
          {building.antenna && <rect x={building.x + building.width / 2 - 1.5} y={400 - building.height - 34} width="3" height="34" />}
          {building.windows.map((window, windowIndex) => <rect key={windowIndex} className="lit-window" x={window.x} y={window.y} width="7" height="11" />)}
        </g>
      ))}
    </svg>
  );
}

function Palm({ className }) {
  return (
    <svg className={className} viewBox="0 0 220 520" aria-hidden="true">
      <path className="palm-trunk" d="M104 520 C 118 400, 90 300, 112 150" />
      <g className="palm-fronds">
        <path d="M112 150 C 70 110, 30 112, 4 150" />
        <path d="M112 150 C 80 92, 44 70, 14 74" />
        <path d="M112 150 C 112 96, 124 56, 150 30" />
        <path d="M112 150 C 150 100, 186 92, 214 110" />
        <path d="M112 150 C 150 130, 190 138, 216 176" />
        <path d="M112 150 C 76 138, 44 160, 30 202" />
      </g>
    </svg>
  );
}

// The dusk skyline shared by the welcome screen and the loading screen. Pure SVG and CSS, so it works offline.
export default function DuskBackdrop({ variant = "welcome" }) {
  return (
    <div className={`dusk-backdrop is-${variant}`} aria-hidden="true">
      <span className="landing-sun" />
      <Skyline className="layer layer-far" seed={11} count={26} minHeight={80} maxHeight={230} />
      <Skyline className="layer layer-mid" seed={29} count={18} minHeight={110} maxHeight={320} lit />
      <Skyline className="layer layer-near" seed={53} count={11} minHeight={150} maxHeight={380} lit />
      <Palm className="palm palm-left" />
      <Palm className="palm palm-right" />
      <span className="road-glow" />
      <span className="streak streak-red" />
      <span className="streak streak-white" />
      <span className="landing-shade" />
    </div>
  );
}

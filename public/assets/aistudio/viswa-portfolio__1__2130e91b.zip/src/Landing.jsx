import { useEffect, useMemo, useRef, useState } from "react";
import DuskBackdrop from "./Backdrop";
import { characters } from "./characters";
import "./landing.css";

const pickVideoQuality = () => {
  if (typeof window === "undefined") return "1080";
  const pixelWidth = window.screen.width * (window.devicePixelRatio || 1);
  const saveData = navigator.connection?.saveData;
  return !saveData && pixelWidth >= 2560 ? "2160" : "1080";
};

function CharacterMedia({ character, active, quality }) {
  const [videoState, setVideoState] = useState("idle"); // idle | ready | failed
  return (
    <div className="char-media">
      <img src={character.image} alt="" loading="lazy" decoding="async" />
      {active && videoState !== "failed" && (
        <video
          className={videoState === "ready" ? "is-ready" : ""}
          src={`${character.video}-${quality}.mp4`}
          poster={character.image}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          onLoadedData={() => setVideoState("ready")}
          onError={() => setVideoState("failed")}
        />
      )}
    </div>
  );
}

export default function Landing({ onStart }) {
  const [selectedId, setSelectedId] = useState(characters[0].id);
  const [pickerOpen, setPickerOpen] = useState(false);
  const rootRef = useRef(null);
  const quality = useMemo(() => pickVideoQuality(), []);
  const selected = characters.find((character) => character.id === selectedId) || characters[0];

  useEffect(() => {
    const onKeyDown = (event) => {
      if (event.key !== "Enter" || event.repeat) return;
      if (event.target instanceof HTMLButtonElement || event.target instanceof HTMLAnchorElement || event.target instanceof HTMLInputElement) return;
      onStart(selected);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [onStart, selected]);

  const handlePointerMove = (event) => {
    const root = rootRef.current;
    if (!root) return;
    root.style.setProperty("--mx", ((event.clientX / window.innerWidth) * 2 - 1).toFixed(3));
    root.style.setProperty("--my", ((event.clientY / window.innerHeight) * 2 - 1).toFixed(3));
  };

  const handleRadioKeys = (event) => {
    const step = event.key === "ArrowRight" || event.key === "ArrowDown" ? 1 : event.key === "ArrowLeft" || event.key === "ArrowUp" ? -1 : 0;
    if (!step) return;
    event.preventDefault();
    const index = characters.findIndex((character) => character.id === selectedId);
    const next = characters[(index + step + characters.length) % characters.length];
    setSelectedId(next.id);
    requestAnimationFrame(() => rootRef.current?.querySelector(`[data-character="${next.id}"]`)?.focus());
  };

  return (
    <div ref={rootRef} className="landing" style={{ "--accent": selected.accent }} onPointerMove={handlePointerMove}>
      <DuskBackdrop variant="welcome" />

      <header className="landing-top">
        <span className="landing-mark" aria-hidden="true">VC</span>
        <a className="classic-link" href="https://viswa-portfolio-nine.vercel.app/" target="_blank" rel="noreferrer">Prefer a standard page? Open the classic portfolio <span aria-hidden="true">↗</span></a>
      </header>

      <main className="landing-main">
        <section className="welcome" aria-labelledby="welcome-title">
          <p className="welcome-kicker">Welcome to</p>
          <h1 id="welcome-title" className="landing-title"><span>Viswa</span><span>City</span></h1>
          <p className="welcome-name"><strong>Viswa R R</strong> · Java Full Stack Developer</p>
          <p className="landing-lede">A Computer Science graduate building web applications with Java, Spring Boot, React, and SQL. Drive across town to explore my work.</p>
          <div className="welcome-actions">
            <button className="start-button" type="button" autoFocus onClick={() => onStart(selected)}>Start exploring</button>
            <button className="ghost-button" type="button" aria-expanded={pickerOpen} aria-controls="character-panel" onClick={() => setPickerOpen((open) => !open)}>
              {pickerOpen ? "Hide characters" : "Choose a character (optional)"}
            </button>
          </div>
          <p className="welcome-hint">Press <kbd>Enter</kbd> to start. You will play as {selected.name}.</p>
        </section>

        {pickerOpen && (
          <section id="character-panel" className="character-select" aria-label="Choose your character, optional">
            <div className="character-row" role="radiogroup" aria-label="Character" onKeyDown={handleRadioKeys}>
              {characters.map((character) => {
                const active = character.id === selectedId;
                return (
                  <button
                    key={character.id}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    tabIndex={active ? 0 : -1}
                    data-character={character.id}
                    className={`character-card${active ? " is-active" : ""}`}
                    style={{ "--card-accent": character.accent }}
                    onClick={() => setSelectedId(character.id)}
                  >
                    <CharacterMedia character={character} active={active} quality={quality} />
                    <span className="char-fade" aria-hidden="true" />
                    <span className="char-name">{character.name}</span>
                    <span className="char-detail"><strong>{character.role}</strong></span>
                  </button>
                );
              })}
            </div>
          </section>
        )}
      </main>

      <footer className="landing-bottom">
        <p>Best on desktop with a keyboard. Phones get on-screen touch controls. Works offline once loaded.</p>
      </footer>
    </div>
  );
}

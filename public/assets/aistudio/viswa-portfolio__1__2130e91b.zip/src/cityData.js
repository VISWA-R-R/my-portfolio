export const cityPlaces = [
  { label: "EDUCATION", position: [-25, 0, -25], color: "#3769c8", height: 4.8, style: "campus" , interactionPosition: [-20, 0, -25] },
  { label: "SKILLS", position: [25, 0, -25], color: "#078a7c", height: 6.2, style: "tower" , interactionPosition: [20, 0, -25] },
  { label: "PROJECTS", position: [-25, 0, 25], color: "#cf7627", height: 4.4, style: "studio" , interactionPosition: [-20, 0, 25] },
  { label: "EXPERIENCE", position: [25, 0, 25], color: "#7742a2", height: 5.6, style: "office" , interactionPosition: [20, 0, 25] },
  { label: "CERTIFICATES", position: [-25, 0, 35], color: "#c14c73", height: 5.2, style: "office" , interactionPosition: [-20, 0, 35] },
  { label: "CONTACT", position: [25, 0, 35], color: "#b83a55", height: 7.2, style: "terminal" , interactionPosition: [20, 0, 35] },
  { label: "GITHUB", position: [-35, 0, -35], color: "#34465f", height: 6.4, style: "tower" , interactionPosition: [-30, 0, -35] },
  { label: "BYTE CAFE", position: [-15, 0, -15], color: "#a95135", height: 2.8, style: "shop" , interactionPosition: [-10, 0, -15] },
  { label: "CAMPUS BOOKS", position: [15, 0, -15], color: "#c08a3f", height: 2.8, style: "shop" , interactionPosition: [10, 0, -15] },
  { label: "CITY GARAGE", position: [-15, 0, 15], color: "#356b78", height: 2.8, style: "shop" , interactionPosition: [-10, 0, 15] },
];

export const residentialPlaces = [
  { id: "cottage-north", type: "home", position: [45, 0, -35], color: "#e7d8b7", roof: "#8f4d43", width: 3.4, depth: 3.1 },
  { id: "cottage-hill", type: "home", position: [45, 0, -25], color: "#d9e0e3", roof: "#45586a", width: 3.4, depth: 3.1 },
  { id: "cottage-park", type: "home", position: [45, 0, -5], color: "#efd3a4", roof: "#a85d43", width: 3.4, depth: 3.1 },
  { id: "villa", type: "villa", position: [45, 0, 15], color: "#d9e2e0", roof: "#394f5e", width: 5.2, depth: 4.5 },
  { id: "cottage-coast", type: "home", position: [45, 0, 35], color: "#d6dfc7", roof: "#5b704e", width: 3.4, depth: 3.1 },
];

export const fishingPondPosition = [45, 0, -15];
export const coastStartX = 60;
